
public class RegularGuest extends Guest {

	public RegularGuest(String name, String birth, String id, String facility, String checkin,
			String checkout, String roomType) {
		super(name, birth, id, facility, checkin, checkout, roomType);
	}
	
	public RegularGuest()
	{
		
	}

}
