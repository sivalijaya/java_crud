
public class RoomType {

	protected long classic = 1000000;
	protected long duluxe = 2000000;
	protected long executive = 3000000;
	protected long superior = 5000000;

}
